// swift-tools-version: 5.9
import PackageDescription
let package=Package(name:"CaresoftVoiceBinary",platforms:[.iOS("15.1")],products:[.library(name:"CaresoftVoice",targets:["CaresoftVoiceDistribution"]),.library(name:"CaresoftVoiceUI",targets:["CaresoftVoiceUI"])],targets:[.binaryTarget(name:"CaresoftVoice",path:"CaresoftVoice.xcframework"),.binaryTarget(name:"WebRTC",path:"WebRTC.xcframework"),.target(name:"CaresoftVoiceDistribution",dependencies:["CaresoftVoice","WebRTC"]),.target(name:"CaresoftVoiceUI",dependencies:["CaresoftVoiceDistribution"])])
