# Third-party notices

| Component | Pinned version | License / source |
|---|---|---|
| Socket.IO-Client-Swift | 16.1.1 | MIT; Licenses/SocketIO-LICENSE; https://github.com/socketio/socket.io-client-swift |
| Starscream | 4.0.8 | Apache-2.0; Licenses/Starscream-LICENSE; https://github.com/daltoniam/Starscream |
| JitsiWebRTC / WebRTC | 124.0.2 | WebRTC BSD-3-Clause baseline; Licenses/WebRTC-LICENSE from branch-heads/6367; https://github.com/jitsi/webrtc |
| Markdown (documentation tool only) | 3.7 | BSD-3-Clause; https://github.com/Python-Markdown/markdown |
| Apple system frameworks | iOS SDK | Apple SDK terms, not redistributed separately |

WebRTC includes upstream third-party code. The reused Jitsi binary's complete transitive notices and current security suitability must be verified with the original release before production redistribution. The root WebRTC license is not a claim that every transitive component is BSD. Vendor hashes are recorded in the delivery manifest.

No Stringee binary/source, PJSIP, Linphone, JsSIP, React Native, Hermes or JavaScriptCore is included in the runtime SDK. Research does not grant rights to redistribute Stringee.

SDK source ownership/production redistribution terms are supplied by the project owner; the podspec's local evaluation metadata is not a public release license. No registry publish was performed.

PrivacyInfo.xcprivacy declares app-functionality transmission of audio and identifying data to the host-configured backend, without tracking. Host must aggregate its own backend retention/recording and app declarations; the SDK cannot infer those policies. Vendor privacy manifests are retained.
