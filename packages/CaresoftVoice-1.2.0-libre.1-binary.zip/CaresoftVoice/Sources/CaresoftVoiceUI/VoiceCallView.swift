#if os(iOS)
  import SwiftUI
  import UIKit
  import CaresoftVoice

  @MainActor public final class VoiceCallViewModel: ObservableObject {
    public let call: VoiceCall
    @Published public private(set) var snapshot: CallSnapshot
    @Published public private(set) var error: String?
    @Published public private(set) var routes: [AudioRoute] = []
    @Published public private(set) var busy = false
    private var subscription: VoiceSubscription?
    public init(call: VoiceCall) {
      self.call = call
      snapshot = call.getSnapshot()
      subscription = call.observe { [weak self] event, _ in
        guard let self else { return }
        self.snapshot = call.getSnapshot()
        if self.snapshot.state == .ended { self.routes = [] }
        if case .stateChanged(let value) = event, value.state == .active { self.refreshRoutes() }
        if case .error(let e) = event { self.error = e.localizedDescription }
        if case .audioRoutesChanged(let routes) = event { self.routes = routes }
      }
      snapshot = call.getSnapshot()
    }
    public var audioRouteName: String {
      guard snapshot.state == .active, let route = routes.first(where: \.selected) else { return "Âm thanh" }
      switch route.id { case "receiver": return "Loa thoại"; case "speaker": return "Loa ngoài"; default: return route.name }
    }
    public var audioRouteIcon: String {
      guard snapshot.state == .active, let route = routes.first(where: \.selected) else { return "iphone" }
      switch route.id { case "speaker": return "speaker.wave.2.fill"; case "receiver": return "iphone"; default: return "headphones" }
    }
    public var endReasonText: String? {
      guard let reason = snapshot.endReason else { return nil }
      switch reason {
      case .localEnded: return "Bạn đã kết thúc cuộc gọi"
      case .remoteEnded: return "Đầu bên kia đã kết thúc cuộc gọi"
      case .rejected: return "Cuộc gọi bị từ chối"
      case .missed: return "Cuộc gọi nhỡ"
      case .answeredElsewhere: return "Đã trả lời trên thiết bị khác"
      case .canceledElsewhere: return "Đã kết thúc trên thiết bị khác"
      case .authFailed: return "Phiên gọi hết hiệu lực"
      case .connectionFailed: return "Không kết nối được cuộc gọi"
      case .busy: return "Đường dây đang bận"
      case .disposed: return "Phiên gọi đã đóng"
      }
    }
    public func perform(exclusive: Bool = true, _ action: @escaping @MainActor (VoiceCall) async throws -> Void) {
      guard call.getSnapshot().state != .ended, !exclusive || !busy else { return }
      if exclusive { busy = true }
      Task { @MainActor [weak self] in
        guard let self else { return }
        defer { if exclusive { busy = false } }
        do {
          try await action(call)
          snapshot = call.getSnapshot()
          error = nil
        } catch {
          snapshot = call.getSnapshot()
          if snapshot.state == .ended, let voiceError = error as? VoiceError,
            ["OPERATION_CANCELED", "INVALID_STATE"].contains(voiceError.code) { return }
          self.error = error.localizedDescription
        }
      }
    }
    public func refreshRoutes() {
      guard call.getSnapshot().state != .ended else { routes = []; return }
      perform(exclusive: false) { [weak self] call in
        guard call.getSnapshot().state != .ended else { return }
        let routes = try await call.getAudioRoutes()
        guard call.getSnapshot().state != .ended else { return }
        self?.routes = routes
      }
    }
  }
  @MainActor public struct VoiceCallView: View {
    @StateObject private var model: VoiceCallViewModel
    @State private var keypad = false
    private let lineLabel: String?
    private let accent = Color(red: 0.03, green: 0.49, blue: 0.46)
    public init(call: VoiceCall, lineLabel: String? = nil) {
      _model = StateObject(wrappedValue: VoiceCallViewModel(call: call))
      self.lineLabel = lineLabel
    }
    private var active: Bool { model.snapshot.state == .active }
    private var ended: Bool { model.snapshot.state == .ended }
    private var incoming: Bool { model.snapshot.direction == .incoming && model.snapshot.state == .ringing }
    private var status: String {
      switch model.snapshot.state {
      case .new, .dialing: return "Đang gọi…"
      case .ringing: return incoming ? "Cuộc gọi đến" : "Đang đổ chuông…"
      case .connecting: return "Đang kết nối…"
      case .active: return model.snapshot.held ? "Đang giữ máy" : "Đang đàm thoại"
      case .ended: return "Cuộc gọi đã kết thúc"
      }
    }
    private func control(_ title: String, icon: String, selected: Bool = false,
                         disabled: Bool = false, action: @escaping () -> Void) -> some View {
      Button(action: action) {
        VStack(spacing: 9) {
          Image(systemName: icon).font(.system(size: 25, weight: .medium))
            .frame(width: 66, height: 66)
            .foregroundColor(selected ? .white : accent)
            .background(selected ? accent : Color.white).clipShape(Circle())
            .overlay(Circle().stroke(accent.opacity(0.12), lineWidth: 1))
          Text(title).font(.system(size: 13, weight: .medium)).foregroundColor(.primary)
        }.frame(maxWidth: .infinity).contentShape(Rectangle())
      }.buttonStyle(.plain).disabled(disabled).opacity(disabled ? 0.4 : 1)
        .accessibilityLabel(title).accessibilityValue(selected ? "Đang bật" : "Đang tắt")
    }
    private func terminalButton(_ title: String, icon: String, color: Color,
                                action: @escaping () -> Void) -> some View {
      Button(action: action) {
        VStack(spacing: 10) {
          Image(systemName: icon).font(.system(size: 30, weight: .semibold))
            .foregroundColor(.white).frame(width: 76, height: 76).background(color).clipShape(Circle())
          Text(title).font(.subheadline.weight(.medium)).foregroundColor(.primary)
        }.frame(minWidth: 100)
      }.buttonStyle(.plain).accessibilityLabel(title)
    }
    public var body: some View {
      ScrollView {
        VStack(spacing: 16) {
          Label(model.snapshot.direction == .incoming ? "CUỘC GỌI ĐẾN" : "CUỘC GỌI ĐI",
                systemImage: model.snapshot.direction == .incoming ? "arrow.down.left" : "arrow.up.right")
            .font(.system(size: 11, weight: .semibold)).foregroundColor(accent)
          VStack(spacing: 10) {
            Image(systemName: "person.fill").font(.system(size: 42, weight: .light))
              .foregroundColor(accent).frame(width: 76, height: 76)
              .background(accent.opacity(0.09)).clipShape(Circle())
              .overlay(Circle().stroke(accent.opacity(0.12), lineWidth: 8)).accessibilityHidden(true)
            Text(model.snapshot.remote.displayName ?? model.snapshot.remote.number ?? "Không rõ người gọi")
              .font(.system(size: 30, weight: .semibold, design: .rounded)).multilineTextAlignment(.center)
              .textSelection(.enabled)
            if let number = model.snapshot.remote.number, model.snapshot.remote.displayName != nil {
              Text(number).font(.title3).foregroundColor(.secondary)
            }
            Text(status).font(.subheadline.weight(.medium)).foregroundColor(accent)
            if let connected = model.snapshot.connectedAt {
              if let end = model.snapshot.endedAt {
                Text(String(format: "%02d:%02d", Int(end.timeIntervalSince(connected)) / 60,
                            Int(end.timeIntervalSince(connected)) % 60)).monospacedDigit()
              } else { Text(connected, style: .timer).monospacedDigit() }
            }
            if let lineLabel {
              Label(lineLabel, systemImage: "simcard").font(.caption).foregroundColor(.secondary)
                .padding(.horizontal, 14).padding(.vertical, 8).background(Color.white.opacity(0.8)).clipShape(Capsule())
            }
          }.padding(.vertical, 4)
          if !ended && !incoming {
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
              control(model.snapshot.muted ? "Bật mic" : "Tắt mic", icon: model.snapshot.muted ? "mic.slash.fill" : "mic.fill",
                      selected: model.snapshot.muted, disabled: model.busy || (!active && model.snapshot.muted)) {
                let value = !model.snapshot.muted
                model.perform { try await $0.setMuted(value) }
              }
              control(model.snapshot.held ? "Tiếp tục" : "Giữ máy", icon: model.snapshot.held ? "play.fill" : "pause.fill",
                      selected: model.snapshot.held, disabled: !active || model.busy) {
                let value = !model.snapshot.held
                model.perform { try await $0.setHeld(value) }
              }
              control("Bàn phím", icon: "circle.grid.3x3.fill", selected: keypad, disabled: !active) { keypad.toggle() }
              Menu {
                ForEach(model.routes, id: \.id) { route in
                  Button((route.selected ? "✓ " : "") + route.name) {
                    model.perform { try await $0.setAudioRoute(id: route.id) }
                  }
                }
              } label: {
                VStack(spacing: 9) {
                  Image(systemName: model.audioRouteIcon).font(.system(size: 25)).foregroundColor(accent)
                    .frame(width: 66, height: 66).background(Color.white).clipShape(Circle())
                  Text(model.audioRouteName).font(.system(size: 13, weight: .medium)).foregroundColor(.primary)
                }.frame(maxWidth: .infinity)
              }.disabled(model.busy).simultaneousGesture(TapGesture().onEnded { model.refreshRoutes() })
                .accessibilityLabel("Chọn tai nghe hoặc loa")
            }.frame(maxWidth: 320)
            if keypad && active {
              LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 12) {
                ForEach(Array("123456789*0#").map(String.init), id: \.self) { digit in
                  Button(digit) { model.perform { try await $0.sendDTMF(digit) } }
                    .font(.title2).frame(width: 58, height: 50).background(Color.white).clipShape(Capsule())
                    .disabled(model.busy).accessibilityLabel("Phím \(digit)")
                }
              }.frame(maxWidth: 280)
            }
          }
          if ended, let reason = model.endReasonText { Text(reason).font(.subheadline).foregroundColor(.secondary) }
          if model.busy { ProgressView("Đang xử lý…").font(.caption) }
          if let error = model.error {
            Label(error, systemImage: "exclamationmark.circle").font(.footnote).foregroundColor(.red)
              .padding(12).frame(maxWidth: .infinity).background(Color.red.opacity(0.06)).cornerRadius(14)
              .accessibilityLabel("Lỗi: \(error)")
          }

        }.padding(20).frame(maxWidth: 480).frame(maxWidth: .infinity)
      }.safeAreaInset(edge: .bottom, spacing: 0) {
          if !ended {
            HStack(spacing: 36) {
              terminalButton(incoming ? "Từ chối" : "Kết thúc", icon: "phone.down.fill", color: .red) {
                model.perform(exclusive: false) { call in
                  if incoming { _ = try await call.reject() } else { _ = try await call.hangup() }
                }
              }
              if incoming {
                terminalButton("Trả lời", icon: "phone.fill", color: accent) {
                  model.perform { try await $0.answer() }
                }.disabled(model.busy)
              } else if model.snapshot.state == .new {
                terminalButton("Gọi", icon: "phone.fill", color: accent) { model.perform { try await $0.start() } }
              }
            }.padding(.vertical, 12).frame(maxWidth: .infinity)
              .background(Color(.systemGroupedBackground))
          }
      }.background(LinearGradient(colors: [accent.opacity(0.07), Color(.systemGroupedBackground)],
                                   startPoint: .top, endPoint: .bottom))
        .clipShape(RoundedRectangle(cornerRadius: 28)).tint(accent).task { model.refreshRoutes() }
    }
  }
  @MainActor public final class VoiceCallViewController: UIHostingController<VoiceCallView> {
    public init(call: VoiceCall) { super.init(rootView: VoiceCallView(call: call)) }
    @available(*, unavailable) required dynamic init?(coder aDecoder: NSCoder) {
      fatalError("Use init(call:)")
    }
  }
#endif
