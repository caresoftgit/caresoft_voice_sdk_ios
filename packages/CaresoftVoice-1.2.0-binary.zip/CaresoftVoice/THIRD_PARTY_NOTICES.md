# Third-party notices

| Component | Pinned version | License / source |
|---|---|---|
| libre | 4.0.0; commit 09bb0afdfaf1aeac21c0979f3857617a88307f3a | BSD-3-Clause; Licenses/libre-LICENSE; https://github.com/baresip/re |
| Caresoft libre bridge | Source included in Native/Libre | BSD-3-Clause; Licenses/CSLibre-LICENSE |
| Socket.IO-Client-Swift | 16.1.1 | MIT; Licenses/SocketIO-LICENSE; https://github.com/socketio/socket.io-client-swift |
| Starscream | 4.0.8 | Apache-2.0; Licenses/Starscream-LICENSE; https://github.com/daltoniam/Starscream |
| JitsiWebRTC / WebRTC | 124.0.2 | WebRTC BSD-3-Clause baseline; Licenses/WebRTC-LICENSE from branch-heads/6367; https://github.com/jitsi/webrtc |
| Markdown (documentation tool only) | 3.7 | BSD-3-Clause; https://github.com/Python-Markdown/markdown |
| Apple system frameworks | iOS SDK | Apple SDK terms, not redistributed separately |

libre and the bridge are statically linked into CaresoftVoice. The pinned source is patched for an external WSS transport; Apple system cryptography supplies hashes. The runtime contains no PJSIP component. BSD notices must accompany source and binary redistribution.

WebRTC includes upstream third-party code. The reused Jitsi binary's complete transitive notices and current security suitability must be verified with the original release before production redistribution. The root WebRTC license is not a claim that every transitive component is BSD. Vendor hashes are recorded in the delivery manifest.

SDK source ownership/production redistribution terms are supplied by the project owner; podspec metadata does not grant third-party redistribution rights. This is the 1.2.0 SDK release; no public package registry publication is claimed.

PrivacyInfo.xcprivacy declares app-functionality transmission of audio and identifying data to the host-configured backend, without tracking. Host must aggregate its own backend retention/recording and app declarations. Vendor privacy manifests are retained.
